<?php
$this->addTranslation([
'HTML text editor, designed to simplify website content creation. Extends the WYSIWYG editor module.' => 'HTML-Texteditor für die Erstellung von Webseiteninhalten. Erweitert das WYSIWYG Editor Modul.',
]);
