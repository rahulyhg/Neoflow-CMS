<?php
$this->addTranslation([
    'Official backend theme of the Neoflow CMS.' => 'Official backend theme of the Neoflow CMS.',
]);
