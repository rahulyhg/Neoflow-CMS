<?php

namespace Neoflow\Mailer;

use RuntimeException;

class MailException extends RuntimeException
{
}
