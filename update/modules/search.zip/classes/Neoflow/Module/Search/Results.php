<?php

namespace Neoflow\Module\Search;

use Neoflow\Framework\Common\Collection;

class Results extends Collection
{
    /**
     * Collection item type.
     *
     * @var string
     */
    protected static $className = '\\Neoflow\\Module\\Search\\Result';
}
