<?php
$this->addTranslation([
'Code editor with syntax highlighting. Extends the code editor module.' => 'Code Editor mit Syntaxhervorhebung. Erweitert das Code Editor Modul.',
]);
