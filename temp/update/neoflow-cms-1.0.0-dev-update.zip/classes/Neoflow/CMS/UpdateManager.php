<?php
namespace Neoflow\CMS\Manager;

class UpdateManager extends AbstractUpdateManager
{
    // Nothing to do... :)
}
