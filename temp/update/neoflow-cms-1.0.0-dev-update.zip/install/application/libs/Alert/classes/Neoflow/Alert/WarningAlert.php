<?php

namespace Neoflow\Alert;

class WarningAlert extends AbstractAlert
{
    protected $type = 'warning';
}
