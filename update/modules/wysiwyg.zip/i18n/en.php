<?php

$this->addTranslation([
'Page module for the presentation and editing of website content.' => 'Page module for the display and editing of website content.',
 'WYSIWYG editor' => 'WYSIWYG editor',
 'No files found' => 'No files found',
 'Uploaded file' => 'Uploaded file|Uploaded files',
]);
