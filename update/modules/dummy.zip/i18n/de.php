<?php

$this->addTranslation([
    'Dummy' => 'Dummy',
    'Dummy page' => 'Dummy-Seite',
    'Dummy page description' => 'Dummy-Seite des Dummy-Moduls als Demo-Beispiel für interessierte Entwickler.',
    'Dummy module as demo example for interested developers.' => 'Dummy-Modul als Demo-Beispiel für interessierte Entwickler.',
]);
