<?php

$this->addTranslation([
'Page module for PHP code editing of website content.' => 'Seitenmodul für die PHP Code Bearbeitung von Webseiteninhalten.',
 'Code editor' => 'Code-Editor',
 'PHP code is invalid.' => 'Der PHP Code ist ungültig.',
 'PHP code is valid.' => 'Der PHP Code ist gültig .',
 'Section code is invalid: "{0}"' => 'Abschnitts-Code ist ungültig: "{0}"',
 'Section code is valid, but has return a string' => 'Abschnitts-Code ist gültig,  muss aber einen String zurückgeben',
]);
