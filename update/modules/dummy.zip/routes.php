<?php

// Module routes
return [
    'routes' => [
        ['tmod_dummy_backend_index', 'get', '/backend/module/dummy', 'Backend@index'],
    ],
    'namespace' => '\\Neoflow\\Module\\Dummy\\Controller\\',
];
