<textarea name="<?= $name; ?>" <?= ($id ? 'id="'.$id.'"' : ''); ?> <?= ($height ? 'height="'.$height.'"' : ''); ?> class="form-control" rows="10" width="100%"><?= $content; ?></textarea>
