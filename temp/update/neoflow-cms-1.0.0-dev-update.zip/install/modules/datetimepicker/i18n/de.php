<?php
$this->addTranslation([
'Datetimepicker, datepicker or timepicker dropdown to your forms.' => 'Dropdown für die Datum- und/oder Zeitauswahl in Formularen.'
]);
