<?php
return [
    'version' => ['1.0.2', 'dev'],
    'for' => [
        ['1.0.1', 'dev'],
        ['1.0.0', 'dev'],
    ],
    'sql' => 'install.sql',
    'files' => 'install',
    'modules' => [
    // 'robots' => 'robots.zip',
    ],
    'themes' => [],
];
