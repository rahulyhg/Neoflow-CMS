<?php

$this->addTranslation([
    'Official backend theme of the Neoflow CMS.' => 'Offizielles Backend-Theme des Neoflow CMS.',
]);
