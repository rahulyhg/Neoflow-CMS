<?php

$this->addTranslation([
    'Robots' => 'Robots',
    'Edit robots.txt' => 'Robots.txt bearbeiten',
    'Editor to edit the content of robots.txt.' => 'Editor um den Inhalt der robots.txt zu bearbeiten.',
]);
