<?php

namespace Neoflow\Framework\HTTP\Responsing;

class Response extends Response
{
}
