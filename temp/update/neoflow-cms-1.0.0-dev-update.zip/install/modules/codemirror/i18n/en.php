<?php

$this->addTranslation([
    'Code editor with syntax highlighting. Extends the code editor module.' => 'Code editor with syntax highlighting. Extends the code editor module.',
]);
