<div class="row">
    <div class="col-xl-7">

        <div class="card">
            <h4 class="card-header">
                <?= translate('Dummy page'); ?>
            </h4>

            <div class="card-body">

                <p>
                    <?= translate('Dummy page description'); ?>
                </p>

            </div>

        </div>

    </div>
    <div class="col-xl-5">

    </div>
</div>

