CREATE TABLE `mod_code` (
    `code_id` INT NOT NULL AUTO_INCREMENT,
    `content` TEXT,
    `section_id` INT NOT NULL,
PRIMARY KEY (`code_id`));
