<?php
$this->addTranslation([
'Page module for PHP code editing of website content.' => 'Page module for PHP code editing of website content.',
 'Code editor' => 'Code editor',
 'PHP code is invalid.' => 'PHP code is invalid.',
 'PHP code is valid.' => 'PHP code is valid.',
 'Section code is invalid: "{0}"' => 'Code of section is invalid: "{0}"',
 'Section code is valid, but has return a string' => 'Code of section is valid, but has return a string',
]);
