<?php

namespace Neoflow\Module\Sitemap\Controller;

use Neoflow\CMS\Controller\Backend\AbstractToolModuleController;
use Neoflow\CMS\View\BackendView;
use Neoflow\Framework\HTTP\Responsing\RedirectResponse;
use Neoflow\Framework\HTTP\Responsing\Response;
use Neoflow\Validation\ValidationException;
use Neoflow\Module\Sitemap\Model;
use Neoflow\Module\Sitemap\Model\SettingModel;
use Neoflow\Module\Sitemap\Service;
use RuntimeException;

class BackendController extends AbstractToolModuleController
{
    /**
     * @var Service
     */
    protected $service;

    public function __construct(BackendView $view = null, array $args = array())
    {
        parent::__construct($view, $args);

        $this->view->setTitle(translate('Sitemap'));

        $this->service = $this->getService('sitemap');
    }

    /**
     * Index action.
     *
     * @return Response
     */
    public function indexAction(): Response
    {
        $settings = SettingModel::findById(1);

        $sitemapFile = $this->service->getFile();

        return $this->render('/sitemap/index', [
                'settings' => $settings,
                'sitemapFile' => $sitemapFile,
                'changeFrequencies' => SettingModel::$changeFrequencies,
                'sitemapLifetimes' => SettingModel::$sitemapLifetimes,
        ]);
    }

    /**
     * Update sitemap settings action.
     *
     * @return RedirectResponse
     *
     * @throws RuntimeException
     */
    public function updateSettingsAction(): RedirectResponse
    {
        // Get post data
        $postData = $this->request()->getPostData();

        try {
            $settings = Model\SettingModel::updateById([
                    'default_changefreq' => $postData->get('default_changefreq'),
                    'default_priority' => $postData->get('default_priority'),
                    'sitemap_lifetime' => $postData->get('sitemap_lifetime'),
                    'automated_creation' => $postData->get('automated_creation'),
                    ], 1);

            // Validate and save settings
            if ($settings && $settings->validate() && $settings->save()) {
                $this->view->setSuccessAlert(translate('Successfully updated'));
            } else {
                throw new RuntimeException('Update settings failed (ID: 1)');
            }
        } catch (ValidationException $ex) {
            $this->view->setWarningAlert([translate('Update failed'), $ex->getErrors()]);
        }

        return $this->redirectToRoute('tmod_sitemap_backend_index');
    }

    /**
     * Create sitemap action.
     *
     * @return RedirectResponse
     *
     * @throws RuntimeException
     */
    public function createAction(): RedirectResponse
    {
        try {
            // Get post data
            $postData = $this->request()->getPostData();

            // Update snippet
            $snippet = Model::updateById(array(
                    'title' => $postData->get('title'),
                    'description' => $postData->get('description'),
                    'placeholder' => $postData->get('placeholder'),
                    'code' => $postData->get('code'),
                    ), $postData->get('snippet_id'));

            // Validate and save snippet
            if ($snippet && $snippet->validate() && $snippet->save()) {
                $this->view->setSuccessAlert(translate('Successfully updated'));
            } else {
                throw new RuntimeException('Updating snippet failed (ID: '.$postData->get('snippet_id').')');
            }
        } catch (ValidationException $ex) {
            $this->view->setWarningAlert([translate('Update failed'), $ex->getErrors()]);
        }

        return $this->redirectToRoute('tmod_snippets_backend_edit', array('id' => $postData->get('snippet_id')));
    }

    /**
     * Delete sitemap action.
     *
     * @return RedirectResponse
     *
     * @throws RuntimeException
     * @throws ValidationException
     */
    public function deleteSitemapAction(): RedirectResponse
    {
        try {
            $sitemapFile = $this->service->getFile();
            if ($sitemapFile) {
                if ($sitemapFile->delete()) {
                    $this->view->setSuccessAlert(translate('Successfully deleted'));
                } else {
                    throw new RuntimeException('Deleting sitemap failed');
                }
            } else {
                throw new ValidationException(translate('Sitemap does not exist and therefore cannot be deleted'));
            }
        } catch (ValidationException $ex) {
            $this->view->setWarningAlert([translate('Delete failed'), $ex->getErrors()]);
        }

        return $this->redirectToRoute('tmod_sitemap_backend_index');
    }

    /**
     * Recreate sitemap action.
     *
     * @return RedirectResponse
     *
     * @throws RuntimeException
     */
    public function recreateSitemapAction(): RedirectResponse
    {
        try {
            if ($this->service->generateAsFile()) {
                $this->view->setSuccessAlert(translate('Successfully recreated'));
            } else {
                throw new RuntimeException('Recreating sitemap failed');
            }
        } catch (ValidationException $ex) {
            $this->view->setWarningAlert([translate('Recreate failed'), $ex->getErrors()]);
        }

        return $this->redirectToRoute('tmod_sitemap_backend_index');
    }
}
