<?php

namespace Neoflow\Alert;

class SuccessAlert extends AbstractAlert
{
    protected $type = 'success';
}
