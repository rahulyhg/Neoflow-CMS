<span class="brand">
    <img class="img-responsive" title="Neoflow CMS" alt="Neoflow CMS" src="<?= $view->getThemeUrl('img/logo-01-200x40.png'); ?>" />
    <span>Content Management System <span><?= $view->get('brandTitle') ?: 'Backend'; ?></span></span>
</span>