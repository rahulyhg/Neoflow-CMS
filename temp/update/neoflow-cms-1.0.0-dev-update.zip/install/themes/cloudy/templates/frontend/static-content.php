<div class="static-content block-<?= $block->block_key; ?>">
    <div class="container">
        <?= $content; ?>
    </div>
</div>