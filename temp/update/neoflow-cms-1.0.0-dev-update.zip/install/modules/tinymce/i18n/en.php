<?php
$this->addTranslation([
'HTML text editor, designed to simplify website content creation. Extends the WYSIWYG editor module.' => 'HTML text editor, designed to simplify website content creation. Extends the WYSIWYG editor module.',
]);
