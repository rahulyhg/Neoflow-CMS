<?= $wysiwyg->content; ?>

