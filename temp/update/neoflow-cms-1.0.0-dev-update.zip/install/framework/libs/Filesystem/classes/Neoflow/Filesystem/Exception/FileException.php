<?php

namespace Neoflow\Filesystem\Exception;

class FileException extends FilesystemException
{
}
