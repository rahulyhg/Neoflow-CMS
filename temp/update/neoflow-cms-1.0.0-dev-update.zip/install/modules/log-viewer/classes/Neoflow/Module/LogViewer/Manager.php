<?php

namespace Neoflow\Module\LogViewer;

use Neoflow\CMS\Manager\AbstractModuleManager;

class Manager extends AbstractModuleManager
{
    /**
     * Install Log Viewer module.
     *
     * @return bool
     */
    public function install(): bool
    {
        // Nothing todo
        return true;
    }

    /**
     * Unintall Log Viewer module.
     *
     * @return bool
     */
    public function uninstall(): bool
    {
        // Nothing todo
        return true;
    }

    /**
     * Update Log Viewer module.
     *
     * @return bool
     */
    public function update(): bool
    {
        // Nothing todo
        return true;
    }
}
