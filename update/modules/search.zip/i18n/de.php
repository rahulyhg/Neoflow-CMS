<?php

$this->addTranslation([
    'Provides a dynamic search.' => 'Stellt eine dynamische Suche zur Verfügung.',
    'The entity class must exist' => 'Die Entitätsklasse muss existieren',
    'The entity class has to implement the model search interface' => 'Die Entitätsklasse muss das ModelSearchInterface implementiert haben',
    'Search result' => 'Suchresultat|Suchresultate',
    'Search results for "{0}"' => 'Suchresultate für "{0}"',
    'The URL is already in use.' => 'Die URL wird schon verwendet.',
    'The search page is active and accessible' => 'Die Suchseite ist aktiv und aufrufbar',
    'The search module has no settings, but can be used in the frontend via this URL:' => 'Das Suchmodul hat keine Einstellungen, kann aber im Frontend über diese URL verwendet werden:',
]);
