<?php

$this->addTranslation([
'Page module for the presentation and editing of website content.' => 'Seitenmodul für die Darstellung und Bearbeitung von Webseiteninhalten.',
 'WYSIWYG editor' => 'WYSIWYG Editor',
 'No files found' => 'Keine Dateien gefunden',
 'Uploaded file' => 'Hochgeladenes Datei|Hochgeladene Dateien',
]);
