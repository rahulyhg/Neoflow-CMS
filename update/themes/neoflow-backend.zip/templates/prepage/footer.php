<div class="row">
    <div class="col-md-6 mx-md-auto col-lg-4 col-xl-3">
        <footer id="prepageFooter">
            Neoflow CMS is released under the <a href="https://github.com/Neoflow/Neoflow-CMS/blob/master/LICENSE">MIT License</a>.
        </footer>
    </div>
</div>