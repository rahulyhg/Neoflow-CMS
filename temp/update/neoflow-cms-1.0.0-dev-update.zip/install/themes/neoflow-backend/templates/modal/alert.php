<div class="modal fade" id="alertModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><?= translate('Please note'); ?></h5>
                <button type="button" class="close" data-dismiss="modal">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">

            </div>
            <div class="modal-footer d-flex justify-content-end">
                <button data-dismiss="modal" class="btn btn-primary btn-icon-left pull-left mr-auto btn-ok">
                    <span class="btn-icon">
                        <i class="fa fa-check"></i>
                    </span>
                    Ok
                </button>
            </div>
        </div>
    </div>
</div>