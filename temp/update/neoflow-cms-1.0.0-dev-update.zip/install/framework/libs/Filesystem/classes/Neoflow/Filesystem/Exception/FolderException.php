<?php

namespace Neoflow\Filesystem\Exception;

class FolderException extends FilesystemException
{
    const CANNOT_DELETE = 201;
}
