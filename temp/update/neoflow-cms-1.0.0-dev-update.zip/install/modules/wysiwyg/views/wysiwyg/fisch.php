<?= $wysiwyg.' - SectionID: '.$section->id(); ?>

<?php

var_dump($args);
?>
