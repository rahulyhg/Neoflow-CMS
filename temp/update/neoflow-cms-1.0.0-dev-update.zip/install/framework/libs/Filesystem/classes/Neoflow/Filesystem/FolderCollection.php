<?php

namespace Neoflow\Filesystem;

/**
 * @method bool delete()                  Delete all folders
 * @method self sortByName(string $order) Sort folders by name
 */
class FolderCollection extends Collection
{
}
