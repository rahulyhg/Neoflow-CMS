<?php
$this->addTranslation([
'User-friendly and simple viewer for in-depth analysis of log files.' => 'User-friendly and simple viewer for in-depth analysis of log files.',
 'Log Viewer' => 'Log viewer',
 'Show logfile' => 'Show logfile',
 'All lines' => 'All lines',
 'Log data not found' => 'Log data not found',
 'Log file "{0}" not found' => 'Log file "{0}" not found',
]);
