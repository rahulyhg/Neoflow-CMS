<?php

$this->addTranslation([
    'Dummy' => 'Dummy',
    'Dummy page' => 'Dummy page',
    'Dummy page description' => 'Dummy page of the dummy module as a demo example for interested developers.',
    'Dummy module as demo example for interested developers.' => 'Dummy module as demo example for interested developers.',
]);
