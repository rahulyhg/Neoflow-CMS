<div class="section-content block-<?= $block->block_key; ?>" id="section-<?= $section->id(); ?>">
    <?= $content; ?>
</div>