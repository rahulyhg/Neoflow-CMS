<?php
$this->addTranslation([
'User-friendly and simple viewer for in-depth analysis of log files.' => 'Benutzerfreundliche und einfache Anzeige für vertiefte Analysen von Protokolldateien.',
 'Log Viewer' => 'Protokollanzeige',
 'Show logfile' => 'Protokolldatei anzeigen',
 'All lines' => 'Alle Zeilen',
 'Log data not found' => 'Keine Protokolldaten gefunden',
 'Log file "{0}" not found' => 'Protokolldatei "{0}" nicht gefunden',
]);
