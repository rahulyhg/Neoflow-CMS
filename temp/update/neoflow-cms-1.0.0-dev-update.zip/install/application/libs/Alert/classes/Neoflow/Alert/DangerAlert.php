<?php

namespace Neoflow\Alert;

class DangerAlert extends AbstractAlert
{
    protected $type = 'danger';
}
