<?php
$this->addTranslation([
'Datetimepicker, datepicker or timepicker dropdown to your forms.' => 'Datetimepicker, datepicker or timepicker dropdown to your forms.',
]);
