<?php

namespace Neoflow\Alert;

class InfoAlert extends AbstractAlert
{
    protected $type = 'info';
}
