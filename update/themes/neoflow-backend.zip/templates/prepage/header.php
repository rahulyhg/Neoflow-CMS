<div class="row">
    <div class="col-md-6 mx-md-auto col-lg-4 col-xl-3">
        <header id="prepageHeader">
            <?= $view->renderTemplate('brand'); ?>
        </header>
    </div>
</div>