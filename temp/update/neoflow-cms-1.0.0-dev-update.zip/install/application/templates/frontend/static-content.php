<div class="static-content block-<?= $block->block_key; ?>">
    <?= $content; ?>
</div>