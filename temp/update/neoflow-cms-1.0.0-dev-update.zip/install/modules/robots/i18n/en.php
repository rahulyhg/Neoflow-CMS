<?php

$this->addTranslation([
    'Robots' => 'Robots',
    'Edit robots.txt' => 'Edit robots.txt',
    'Editor to edit the content of robots.txt.' => 'Editor to edit the content of robots.txt.',
]);
